package com.affanshaikhsurab.myapplication;

import android.app.Activity;
import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintSet;

import java.util.List;

public class CareerAdapter extends ArrayAdapter<Careers> {


   public CareerAdapter(Activity context , ArrayAdapter<Careers> Careers)
   {
       super(context , 0 , (List<com.affanshaikhsurab.myapplication.Careers>) Careers);
   }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View listview = convertView;
        if (listview == null){
            listview = LayoutInflater.from(getContext()).inflate(R.layout.list , parent , false);

        }
       Careers career = getItem(position);

        TextView Name = listview.findViewById(R.id.textView);
        Name.setText(career.getName());

        ImageView image = listview.findViewById(R.id.imageView);
        image.setImageURI(career.getImage());

        return listview;
    }
}
