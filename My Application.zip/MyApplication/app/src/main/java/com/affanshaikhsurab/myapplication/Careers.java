package com.affanshaikhsurab.myapplication;

import android.net.Uri;

public class Careers {
    private String name ;
        private Uri image ;

    public Careers(String namee , Uri imagee)
    {
        name = namee;
        image = imagee;
    }

    public String getName() {
        return name;
    }

    public Uri getImage() {
        return image;
    }
}
